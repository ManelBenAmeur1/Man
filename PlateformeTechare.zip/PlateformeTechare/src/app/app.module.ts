import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './component/home/home.component';
import {FormationMEtierModule} from './component/formation-metier/formation-metier.module';
import { FormationMetierComponent } from './component/Model/formation-metier/formation-metier.component';
import { FormationModuleComponent } from './component/Model/formation-module/formation-module.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FormationMetierComponent,
    FormationModuleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormationMEtierModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
